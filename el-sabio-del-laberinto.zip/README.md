# el-sabio-del-laberinto
Proyecto de Haskell de Laboratorio de Lenguajes de Programación
